package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener{
 
    JButton rules, back ,next;
    JTextField tfname;
    Connection conn;
    Statement stmt;
    
    Login() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sql_demo","root","@Akj123456");
            System.out.println("Connected to database!");
            stmt = conn.createStatement();

            /*String sql = "CREATE TABLE Credentials_user " +
            "(user_name VARCHAR(255), " +
            "user_password VARCHAR(255), " +
            "score INT, " +
            "PRIMARY KEY (user_name))";

            stmt.executeUpdate(sql);
            System.out.println("Table successfully created");
            stmt.close();
            */
            




              
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }

        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login.jpeg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 600, 500);
        add(image);
        
        JLabel heading = new JLabel("Quiz Game");
        heading.setBounds(750, 60, 300, 45);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 40));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        JLabel name = new JLabel("Enter your name");
        name.setBounds(810, 150, 300, 20);
        name.setFont(new Font("Times New Roman", Font.BOLD, 18));
        name.setForeground(new Color(30, 144, 254));
        add(name);
        
        tfname = new JTextField();
        tfname.setBounds(735, 200, 300, 25);
        tfname.setFont(new Font("Times New Roman", Font.BOLD, 20));
        add(tfname);
        
        rules = new JButton("Rules");
        rules.setBounds(675, 270, 120, 25);
        rules.setBackground(new Color(30, 144, 254));
        rules.setForeground(Color.WHITE);
        rules.addActionListener(this);
        add(rules);
        

        
        next = new JButton("Next");
        next.setBounds(1000, 270, 120, 25);
        next.setBackground(new Color(30, 144, 254));
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        add(next);
        
        back = new JButton("Back");
        back.setBounds(850, 270, 120, 25);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
        
        setSize(1200, 500);
        setLocation(200, 150);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == rules) {
            String name = tfname.getText();
            setVisible(false);
            new Rules(name);
        } else if (ae.getSource() == back) {
            setVisible(false);
        }
        else if (ae.getSource() == next) {
          
            String name = tfname.getText();
            try {
                String insertQuery = "INSERT INTO Credentials_user (user_name) VALUES ('" + name + "')";
                stmt.executeUpdate(insertQuery);
                stmt.close();
                conn.close();
                
            } catch (Exception ex) {
                // TODO: handle exception
                ex.printStackTrace();

            }
            setVisible(false);
            new Quiz(name);
            
        }
        
    }
    
    public static void main(String[] args) {
        new Login();
        
    }
}
