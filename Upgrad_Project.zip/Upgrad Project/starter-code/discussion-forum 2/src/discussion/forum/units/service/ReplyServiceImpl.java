package discussion.forum.units.service;

import java.util.ArrayList;
import java.util.Iterator;

import com.forum.units.Question;
import com.forum.units.Reply;
import com.forum.units.User;
import com.forum.util.Utility;

public class ReplyServiceImpl implements ReplyService {
	public static ArrayList<Reply> replies = new ArrayList<>();

	public ReplyServiceImpl() {
	}


	public Reply addReply(String message, Question question, User user) {
		if (Utility.isNotNullAndEmpty(message) && question != null && user != null) {
			Reply reply = getReply(question, message);
			if (reply != null) {
				System.out.println("This reply is already present for this question");
				return reply;
			}else{
				reply = new Reply();
				reply.setMessage(message);
				reply.setQuestion(question);
				reply.setUser(user);
				reply.autoGenerateId();
				reply.setCreated();
				replies.add(reply);
				return reply;
			}

		}else{
			System.out.println("Any specified field can't be empty");
			return null;
		}

	}
	
	private Reply getReply(Question question, String replyMessage) {
		Iterator var3 = replies.iterator();

		Reply reply;
		do {
			if (!var3.hasNext()) {
				return null;
			}

			reply = (Reply)var3.next();
		} while(reply.getQuestion() != question || !reply.getMessage().equals(replyMessage));

		return reply;
	}
	public Reply getReply(long id) {
		Iterator var3 = replies.iterator();

		Reply reply;
		do {
			if (!var3.hasNext()) {
				return null;
			}

			reply = (Reply)var3.next();
		} while(reply.getId() != id);

		return reply;
	}


	public ArrayList<Reply> getReplies(Question question) {
		ArrayList<Reply> repliesToQuestion = new ArrayList<>();
		Iterator var3 = replies.iterator();

		while(var3.hasNext()) {
			Reply reply = (Reply)var3.next();
			if (reply.getQuestion() == question) {
				repliesToQuestion.add(reply);
			}
		}

		return repliesToQuestion;
	}


	public void deleteReply(Reply reply) {
		replies.remove(reply);
	}
}
