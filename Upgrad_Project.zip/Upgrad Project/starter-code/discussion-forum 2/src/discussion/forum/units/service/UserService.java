package discussion.forum.units.service;

import com.forum.units.User;
import com.forum.units.UserRole;

public interface UserService {
	User createUser(String var1, String var2, String var3, UserRole var4);
	
	User getUser(String var1, String var2);
}
