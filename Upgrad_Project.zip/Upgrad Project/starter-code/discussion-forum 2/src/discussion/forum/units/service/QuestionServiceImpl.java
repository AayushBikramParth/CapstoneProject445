package discussion.forum.units.service;

import java.util.ArrayList;
import java.util.Iterator;

import com.forum.units.Question;
import com.forum.units.User;
import com.forum.util.Utility;

public class QuestionServiceImpl implements QuestionService {
	public static ArrayList<Question> questions = new ArrayList<>();

	public QuestionServiceImpl() {
	}


	public Question createQuestion(String title, String message, User user) {
		if (Utility.isNotNullAndEmpty(title) && Utility.isNotNullAndEmpty(message) && user != null) {
			Question question = this.getQuestionByBody(message);
			if (question != null) {
				System.out.println("Asked question already exists with same body");
				return question;
			}else{
				question = new Question();
				question.autoGenerateId();
				question.setTitle(title);
				question.setMessage(message);
				question.setUser(user);
				question.setCreated();
				questions.add(question);
				return question;
			}
		}
		else{
			System.out.println("Any specified field can't be empty");
			return null;
		}

	}
	
	private Question getQuestionByBody(String questionMessage) {
		Iterator var2 = questions.iterator();

		Question question;
		do {
			if (!var2.hasNext()) {
				return null;
			}

			question = (Question)var2.next();
		} while(!question.getMessage().equals(questionMessage));

		return question;
	}
	
	public Question getQuestionById(long id) {
		Iterator var3 = questions.iterator();

		Question question;
		do {
			if (!var3.hasNext()) {
				return null;
			}

			question = (Question)var3.next();
		} while(question.getId() != id);

		return question;
	}

	public void deleteQuestion(Question question) {
		long qId = question.getId();
		questions.remove(question);
		Iterator var4 = questions.iterator();

		while(var4.hasNext()) {
			Question q1 = (Question)var4.next();
			if (q1.getId() > qId) {
				q1.setId(qId);
				++qId;
			}
		}
	}
}
