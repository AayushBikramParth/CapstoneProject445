package discussion.forum.units.service;

import com.forum.units.Question;
import com.forum.units.User;

public interface QuestionService {
	Question createQuestion(String var1 , String var2 , User var3 );
	
	Question getQuestionById(long var1);
	
	void deleteQuestion(Question var1);
}
