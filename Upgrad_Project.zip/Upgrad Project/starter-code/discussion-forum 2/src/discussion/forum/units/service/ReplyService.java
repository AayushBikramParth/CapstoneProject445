package discussion.forum.units.service;

import java.util.ArrayList;

import com.forum.units.Question;
import com.forum.units.Reply;
import com.forum.units.User;

public interface ReplyService {
	Reply addReply(String var1, Question var2, User var3);
	
	Reply getReply(long var1);
	
	ArrayList<Reply> getReplies(Question var1);
	
	void deleteReply(Reply var1);
}
