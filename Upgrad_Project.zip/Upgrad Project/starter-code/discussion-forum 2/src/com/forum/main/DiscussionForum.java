package com.forum.main;

import java.io.IOException;
import java.io.PrintStream;

import com.forum.units.Question;
import com.forum.units.User;
import com.forum.units.UserRole;
import com.forum.util.Utility;

import discusion.forum.activiy.UserActivity;

public class DiscussionForum {
	static boolean logOutAndExit = false;

	public DiscussionForum(){

	}
	
	public static void main(String args[]) throws IOException {
		User user;
		UserActivity userActivity = new UserActivity();
		userActivity.userService.createUser("admin", "admin", "admin", UserRole.ADMIN);
		do {
			User user;
			do {
				user = userActivity.loginActivity();
			} while(user == null);
			System.out.println("Welcome " + user.getUsername());
			menu(user, userActivity);
		} while(!logOutAndExit);
	}
	
	public static void menu(User user, UserActivity userActivity) throws NumberFormatException, IOException {
		while (true) {
			int inputFromUser;
			try {
				int menuIndex = 0;
				PrintStream var10000;
				StringBuilder var10001;
				if (user.getUserRole() == UserRole.ADMIN) {
					var10000 = System.out;
					var10001 = new StringBuilder();
					++menuIndex;
					var10000.println(var10001.append(menuIndex).append(" Create new user").toString());
				}
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Ask a question").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" See all questions").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Log Out").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Exit and Logout").toString());

				System.out.println("\n Enter your choice");
				inputFromUser = Integer.parseInt(Utility.inputFromUser());
			} catch (Exception var5) {
				System.out.println("Wrong Choice, Only numbers accepted. Try again \n");
				continue;
			}
			if (!classifyMenuChoice(inputFromUser, userActivity, user))
				return;
		   }
		}
	}
	
	public static boolean classifyMenuChoice(int choice, UserActivity userActivity, User user) throws IOException {
		if (UserRole.ADMIN != user.getUserRole()) {
			++choice;
		}
		while (true) {
			switch (choice) {
				case 1:
					userActivity.createNewUser();
					return true;
				case 2:
					userActivity.postNewQuestion(user);
					return true;
				case 3:
					userActivity.seeAllQuestions(userActivity, user);
					return true;
				case 4:
					return false;
				case 5:
					logOutAndExit = true;
					return false;
				default:
					System.out.println("Wrong choice. Try again");
					System.out.println("\n Enter your choice");
					choice = Integer.parseInt(Utility.inputFromUser());
			}
		}
	}
	
	public static UserRole roleFromMenu() throws NumberFormatException, IOException {
		while (true) {
			try {
				int menuIndex = 0;
				PrintStream var10000 = System.out;
				StringBuilder var10001 = new StringBuilder();
				int menuIndex = menuIndex + 1;
				var10000.println(var10001.append(menuIndex).append(UserRole.ADMIN.toString()).toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(UserRole.MODERATOR.toString()).toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(UserRole.USER.toString()).toString());
				while (true) {
					System.out.println("\n Enter your choice");
					int choice = Integer.parseInt(Utility.inputFromUser());
					switch (choice) {
						case 1:
							return UserRole.ADMIN;
						case 2:
							return UserRole.MODERATOR;
						case 3:
							return UserRole.USER;
						default:
							System.out.println("Wrong choice. Try again");
					}
				}
			} catch (Exception var2) {
				System.out.println("Wrong Choice, Only numbers accepted. Try again \n");
			}
		}
	}

	public static void questionMenu(UserActivity userActivity, User user) throws NumberFormatException, IOException {
		while (true) {
			int inputFromUser;
			try {
				int menuIndex = 0;
				PrintStream var10000 = System.out;
				StringBuilder var10001 = new StringBuilder();
				int menuIndex = menuIndex + 1;
				var10000.println(var10001.append(menuIndex).append(" Upvote a question").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Reply to a question").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" See replies for a question").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Delete a question").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Return to main menu").toString());
				System.out.println("\n Enter your choice");
				inputFromUser = Integer.parseInt(Utility.inputFromUser());
			} catch (Exception var5) {
				System.out.println("Wrong Choice, Only numbers accepted. Try again \n");
				continue;
			}
			if (!processQuestionChoice(inputFromUser, userActivity, user)) {
				return;
			}
		}
	}
	
	public static boolean processQuestionChoice(int choice, UserActivity userActivity, User user) throws NumberFormatException, IOException {
		while (true) {
			switch (choice) {
				case 1:
					userActivity.upvoteQuestion(user);
					return true;
				case 2:
					userActivity.replyToQuestion(user);
					return true;
				case 3:
					userActivity.seeAllReplies(userActivity, user);
					return true;
				case 4:
					userActivity.deleteQuestion(userActivity, user);
					return true;
				case 5:
					return false;
				default:
					System.out.println("Wrong choice. Try again");
					System.out.println("Enter your choice");
					choice = Integer.parseInt(Utility.inputFromUser());
			}

		}
	}
	
	public static void replyMenu(UserActivity userActivity, User user, Question question) throws NumberFormatException, IOException {
		while (true) {
			int inputFromUser;
			try {
				int menuIndex = 0;
				PrintStream var10000 = System.out;
				StringBuilder var10001 = new StringBuilder();
				int menuIndex = menuIndex + 1;
				var10000.println(var10001.append(menuIndex).append(" Upvote a reply").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Delete a reply").toString());
				var10000 = System.out;
				var10001 = new StringBuilder();
				++menuIndex;
				var10000.println(var10001.append(menuIndex).append(" Return to question menu").toString());
				System.out.println("\n Enter your choice");
				inputFromUser = Integer.parseInt(Utility.inputFromUser());
			} catch (Exception var6) {
				System.out.println("Wrong Choice, Only numbers accepted. Try again \n");
				continue;
			}

			if (!processReplyChoice(inputFromUser, userActivity, user, question)) {
				return;
			}
		}
	}
	
	public static boolean processReplyChoice(int choice, UserActivity userActivity, User user, Question question) throws NumberFormatException, IOException {
		while (true) {
			switch (choice) {
				case 1:
					userActivity.upvoteReply(user);
					return true;
				case 2:
					userActivity.deleteReply(question, userActivity, user);
					return true;
				case 3:
					return false;
				default:
					System.out.println("Wrong choice. Try again");
			}
		}
	}
}
