
//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//
package com.forum.units;

import com.forum.util.Utility;
import java.util.Date;

public abstract class AbstractEntity {

	private Date created;
	private long id;


	// Please write code for the s method here
	public AbstractEntity() {
	}
	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public abstract void autoGenerateId();



	public Date getCreated() {
		return this.created;
	}

	public void setCreated() {
		this.created = Utility.getCurrentDate();
	}
}
