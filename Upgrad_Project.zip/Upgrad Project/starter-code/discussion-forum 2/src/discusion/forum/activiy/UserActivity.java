package discusion.forum.activiy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import com.forum.main.DiscussionForum;
import com.forum.units.Question;
import com.forum.units.Reply;
import com.forum.units.User;
import com.forum.units.UserRole;
import com.forum.util.Utility;

import discussion.forum.units.service.QuestionService;
import discussion.forum.units.service.QuestionServiceImpl;
import discussion.forum.units.service.ReplyService;
import discussion.forum.units.service.ReplyServiceImpl;
import discussion.forum.units.service.UpvoteService;
import discussion.forum.units.service.UpvoteServiceImpl;
import discussion.forum.units.service.UserService;
import discussion.forum.units.service.UserServiceImpl;

public class UserActivity {
	public UserService userService = new UserServiceImpl();
	public QuestionService questionService = new QuestionServiceImpl();
	public ReplyService replyService = new ReplyServiceImpl();
	public UpvoteService upvoteService = new UpvoteServiceImpl();

	public UserActivity() {

	}

	public User loginActivity() throws IOException {
		System.out.println("Welcome to discussion forum login");
		System.out.println("Enter your username : ");
		String username = Utility.inputFromUser();
		System.out.println("Enter your password : ");
		String password = Utility.inputFromUser();
		User user = this.userService.getUser(username, password);
		if (user != null) {
			return user;
		}else{
			System.out.println("You do not have the account. Request admin to get account in discussion forum");
			return null;
		}

	}

	public void createNewUser() throws IOException {
		System.out.println("Enter username : ");
		String username = Utility.inputFromUser();
		System.out.println("Enter password : ");
		String password = Utility.inputFromUser();
		System.out.println("Enter email : ");
		String email = Utility.inputFromUser();
		System.out.println("What role : ");
		UserRole role = DiscussionForum.roleFromMenu();
		this.userService.createUser(username, password, email, role);
	}

	public void postNewQuestion(User user) throws IOException {
		System.out.println("Enter question title : ");
		String title = Utility.inputFromUser();
		System.out.println("Enter question : ");
		String message = Utility.inputFromUser();
		this.questionService.createQuestion(title, message, user);
	}

	public void seeAllQuestions(UserActivity userActivity, User user) throws NumberFormatException, IOException {
		ArrayList<Question> questions = QuestionServiceImpl.questions;
		if (questions.size() == 0 ) {
			System.out.println("No question posted yet");
		} else {
			this.sort(questions); // sorting the questions from the newest to the oldest
			Iterator var4 = questions.iterator();
			while(var4.hasNext()) {
				Question question = (Question)var4.next();
				System.out.println(question.getId() + ". Question Title - " + question.getTitle());
				System.out.println("Question - " + question.getMessage());
				System.out.println("Upvote - " + question.getUpvoteCount());
			}
			DiscussionForum.questionMenu(userActivity, user);
		}
	}

	public void sort(ArrayList<Question> questions) {
		Collections.sort(questions, new Comparator<Question>() {
			public int compare(Question q1, Question q2) {
				if (q1.getUpvoteCount() == q2.getUpvoteCount()){
					return 0;
				}else{
					return q1.getUpvoteCount() < q2.getUpvoteCount() ? 1 : -1;
				}
			}
		});
	}

	public void upvoteQuestion(User user) throws NumberFormatException, IOException {
		System.out.println("Enter question number you want to upvote : ");
		this.upvoteService.addUpvote(this.getQuestion(), user);
	}

	public void replyToQuestion(User user) throws IOException {
		System.out.println("Enter question number you want to reply to : ");
		Question question = this.getQuestion();
		System.out.println("Post your reply");
		this.replyService.addReply(Utility.inputFromUser(), question, user);
	}


	public void deleteQuestion(UserActivity userActivity, User user) throws NumberFormatException, IOException {
		System.out.println("Enter question number you want to delete : ");
		Question question = this.getQuestion();
		User user1 = question.getUser();


		if (user.getUserRole() == UserRole.ADMIN) { // the user is an admin
			this.questionService.deleteQuestion(question);
			System.out.println("Question Number " + question.getId() + " Deleted Successfully");
		}else if(user.getUserRole() == UserRole.MODERATOR){
			if (user1.getUserRole() != UserRole.USER && user.getUsername() != user1.getUsername()){
				System.out.println("You are not authorised to delete this question");
			}else{
				this.questionService.deleteQuestion(question);
				System.out.println("Question Number " + question.getId() + " Deleted Successfully");
			}
		}
		else if (user.getUserRole() == UserRole.USER){
			if (user1.getUsername() == user.getUsername()){
				this.questionService.deleteQuestion(question);
				System.out.println("Question Number " + question.getId() + " Deleted Successfully");
			}else{
				System.out.println("You are not authorised to delete this question");
			}
		}

		if (QuestionServiceImpl.questions.size() == 0)
			DiscussionForum.menu(user, userActivity);
	}

	private Question getQuestion() throws NumberFormatException, IOException {
		long inputFromUser = 0L;
		while(true) {
			while (true) {
				try {
					inputFromUser = Long.parseLong(Utility.inputFromUser());
					break;
				} catch (Exception var5) {
					System.out.println("Wrong Choice, Only numbers accepted. Try again \n");
				}
			}
		}
		Question question = this.questionService.getQuestionById(inputFromUser);
		if (question != null) {
			return question;
		}

		System.out.println("Enter correct question from displayed questions");
	}
	}

	public void seeAllReplies(UserActivity userActivity, User user) throws NumberFormatException, IOException {
		System.out.println("For which question number you want to see replies : ");
		Question question = this.getQuestion();
		ArrayList<Reply> replies = this.replyService.getReplies(question);
		if (replies.size() == 0) {
			System.out.println("No reply posted yet");
		} else {
			Iterator var5 = replies.iterator();

			while(var5.hasNext()) {
				Reply reply = (Reply)var5.next();
				System.out.println(reply.getId() + ". Comment - " + reply.getMessage());
				System.out.println("Upvote - " + this.upvoteService.upvoteCount(reply));
			}
			DiscussionForum.replyMenu(userActivity, user, question);
		}
	}

	public void upvoteReply(User user) throws NumberFormatException, IOException {
		System.out.println("Enter reply number you want to upvote : ");
		this.upvoteService.addUpvote(getReply(), user);
	}

	public void deleteReply(Question question, UserActivity userActivity, User user) throws NumberFormatException, IOException {
		System.out.println("Enter reply number you want to delete : ");
		Reply reply = this.getReply();
		if (user.getUserRole() == UserRole.ADMIN) {
			this.replyService.deleteReply(reply);
		} else if (user.getUserRole() == UserRole.MODERATOR) {
			if (reply.getUser().getUserRole() == UserRole.USER) {
				this.replyService.deleteReply(reply);
			} else if (reply.getUser() == user) {
				this.replyService.deleteReply(reply);
			} else {
				System.out.println("You are not authorised to delete this reply");
			}
		} else {
			if (reply.getUser() == user) {
				replyService.deleteReply(reply);
			} else {
				System.out.println("You are not authorised to delete this reply");
			}
		}else if(reply.getUser() == user) {
			this.replyService.deleteReply(reply);
		}
		else {
			System.out.println("You are not authorised to delete this reply");
		}
		if (this.replyService.getReplies(question).size() == 0) {
			DiscussionForum.questionMenu(userActivity, user);
		}

	}

	private Reply getReply() throws NumberFormatException, IOException {
		Reply reply;
		while (true) {
			reply = this.replyService.getReply(Long.parseLong(Utility.inputFromUser()));
			if (reply != null)
				return reply;
			System.out.println("Enter correct reply from displayed replies");
		}
	}

}
